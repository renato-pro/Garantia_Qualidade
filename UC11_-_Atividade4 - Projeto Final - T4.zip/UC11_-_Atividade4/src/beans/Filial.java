
package beans;

/**
 * @author Renato Melo - 02/Jul/25
 */
public class Filial {
    
    private int id;
    private String nome_filial;

    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    public String getNome_filial() {
	return nome_filial;
    }

    public void setNome_filial(String nome_filial) {
	this.nome_filial = nome_filial;
    }
    
}
